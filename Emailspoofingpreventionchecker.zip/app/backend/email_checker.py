import sys

def check_email_headers(email_headers):
    if "Received:" in email_headers:
        return "Header Received: Email Passed Basic Check"
    else:
        return "No 'Received' Header Found: Potential Spoofing"

if __name__ == "__main__":
    email_headers = sys.stdin.read()  # Read input from Flask
    print(check_email_headers(email_headers))  # Output result
