from dash import Dash, html, dcc
import plotly.express as px
import plotly.graph_objects as go
from dash.dependencies import Input, Output
import pandas as pd
from datetime import datetime, timedelta
import json
from collections import Counter
from flask import Flask
import os

# Initialize the Dash app
def create_dashboard(server):
    dash_app = Dash(__name__, server=server, url_base_pathname='/dashboard/')
    
    # Dashboard layout
    dash_app.layout = html.Div([
        html.Div([
            html.H1("Email Security Intelligence Dashboard", className="dashboard-title"),
            html.P("Real-time monitoring of email security threats and authentication patterns", 
                   className="dashboard-subtitle")
        ], className="header"),
        
        # Stats Cards Row
        html.Div([
            html.Div([
                html.H3("Total Analyses"),
                html.H2(id="total-analyses"),
                html.P("Last 24 hours")
            ], className="stat-card"),
            html.Div([
                html.H3("Failed Authentications"),
                html.H2(id="failed-auth"),
                html.P("Critical security issues")
            ], className="stat-card"),
            html.Div([
                html.H3("High Risk Emails"),
                html.H2(id="high-risk"),
                html.P("Requires immediate attention")
            ], className="stat-card")
        ], className="stats-container"),
        
        # Charts Row 1
        html.Div([
            html.Div([
                html.H3("Authentication Status Trends"),
                dcc.Graph(id='auth-trends')
            ], className="chart-card"),
            html.Div([
                html.H3("Risk Distribution"),
                dcc.Graph(id='risk-distribution')
            ], className="chart-card")
        ], className="charts-row"),
        
        # Charts Row 2
        html.Div([
            html.Div([
                html.H3("Top Attacked Domains"),
                dcc.Graph(id='attacked-domains')
            ], className="chart-card"),
            html.Div([
                html.H3("Hourly Attack Pattern"),
                dcc.Graph(id='attack-pattern')
            ], className="chart-card")
        ], className="charts-row"),
        
        # Auto-refresh interval
        dcc.Interval(
            id='interval-component',
            interval=30*1000,  # in milliseconds (30 seconds)
            n_intervals=0
        )
    ])
    
    # Callback to update total analyses
    @dash_app.callback(
        Output('total-analyses', 'children'),
        Input('interval-component', 'n_intervals')
    )
    def update_total_analyses(n):
        return len(load_analysis_data())
    
    # Callback to update failed authentications
    @dash_app.callback(
        Output('failed-auth', 'children'),
        Input('interval-component', 'n_intervals')
    )
    def update_failed_auth(n):
        data = load_analysis_data()
        failed = sum(1 for entry in data if any(
            result == 'fail' for result in entry['results'].values()
        ))
        return failed
    
    # Callback to update high risk count
    @dash_app.callback(
        Output('high-risk', 'children'),
        Input('interval-component', 'n_intervals')
    )
    def update_high_risk(n):
        data = load_analysis_data()
        high_risk = sum(1 for entry in data if calculate_risk_score(entry['results']) > 60)
        return high_risk
    
    # Callback to update authentication trends chart
    @dash_app.callback(
        Output('auth-trends', 'figure'),
        Input('interval-component', 'n_intervals')
    )
    def update_auth_trends(n):
        data = load_analysis_data()
        dates = [entry['timestamp'] for entry in data]
        spf_results = [entry['results']['SPF'] for entry in data]
        dkim_results = [entry['results']['DKIM'] for entry in data]
        dmarc_results = [entry['results']['DMARC'] for entry in data]
        
        fig = go.Figure()
        for auth_type, results in [('SPF', spf_results), 
                                 ('DKIM', dkim_results), 
                                 ('DMARC', dmarc_results)]:
            pass_count = [1 if r == 'pass' else 0 for r in results]
            fig.add_trace(go.Scatter(
                x=dates,
                y=pass_count,
                name=auth_type,
                mode='lines+markers'
            ))
        
        fig.update_layout(
            yaxis_title="Pass Rate",
            hovermode='x unified',
            showlegend=True,
            template="plotly_dark"
        )
        return fig
    
    # Callback to update risk distribution chart
    @dash_app.callback(
        Output('risk-distribution', 'figure'),
        Input('interval-component', 'n_intervals')
    )
    def update_risk_distribution(n):
        data = load_analysis_data()
        risk_scores = [calculate_risk_score(entry['results']) for entry in data]
        
        risk_levels = ['Low Risk', 'Medium Risk', 'High Risk']
        counts = [
            sum(1 for score in risk_scores if score <= 30),
            sum(1 for score in risk_scores if 30 < score <= 60),
            sum(1 for score in risk_scores if score > 60)
        ]
        
        fig = go.Figure(data=[go.Pie(
            labels=risk_levels,
            values=counts,
            hole=.3,
            marker_colors=['#10b981', '#f59e0b', '#ef4444']
        )])
        
        fig.update_layout(
            showlegend=True,
            template="plotly_dark"
        )
        return fig
    
    # Callback to update attacked domains chart
    @dash_app.callback(
        Output('attacked-domains', 'figure'),
        Input('interval-component', 'n_intervals')
    )
    def update_attacked_domains(n):
        data = load_analysis_data()
        domains = extract_domains(data)
        domain_counts = Counter(domains).most_common(10)
        
        fig = go.Figure(data=[go.Bar(
            x=[count for _, count in domain_counts],
            y=[domain for domain, _ in domain_counts],
            orientation='h'
        )])
        
        fig.update_layout(
            xaxis_title="Number of Attempts",
            template="plotly_dark"
        )
        return fig
    
    # Callback to update attack pattern chart
    @dash_app.callback(
        Output('attack-pattern', 'figure'),
        Input('interval-component', 'n_intervals')
    )
    def update_attack_pattern(n):
        data = load_analysis_data()
        hours = [datetime.strptime(entry['timestamp'], 
                                 "%Y-%m-%d %H:%M:%S").hour 
                for entry in data]
        
        hour_counts = Counter(hours)
        hours_all = list(range(24))
        counts = [hour_counts.get(hour, 0) for hour in hours_all]
        
        fig = go.Figure(data=go.Scatter(
            x=hours_all,
            y=counts,
            fill='tozeroy'
        ))
        
        fig.update_layout(
            xaxis_title="Hour of Day",
            yaxis_title="Number of Attempts",
            template="plotly_dark"
        )
        return fig
    
    return dash_app

def load_analysis_data():
    """Load analysis data from logs"""
    log_file = 'logs/analysis.log'
    data = []
    
    if os.path.exists(log_file):
        with open(log_file, 'r') as f:
            for line in f:
                try:
                    # Parse log entry and extract relevant information
                    if "Analysis completed" in line:
                        entry = parse_log_entry(line)
                        if entry:
                            data.append(entry)
                except:
                    continue
    
    return data

def parse_log_entry(line):
    """Parse a log entry and extract relevant information"""
    try:
        # Extract timestamp
        timestamp = line[1:20]
        
        # Extract results
        if "Results: " in line:
            results_str = line.split("Results: ")[1]
            spf = results_str.split("SPF=")[1].split(",")[0]
            dkim = results_str.split("DKIM=")[1].split(",")[0]
            dmarc = results_str.split("DMARC=")[1].split()[0]
            
            return {
                'timestamp': timestamp,
                'results': {
                    'SPF': spf,
                    'DKIM': dkim,
                    'DMARC': dmarc
                }
            }
    except:
        return None

def calculate_risk_score(results):
    """Calculate risk score based on authentication results"""
    score = 0
    if results['SPF'] == 'fail':
        score += 30
    if results['DKIM'] == 'fail':
        score += 30
    if results['DMARC'] == 'fail':
        score += 40
    return score

def extract_domains(data):
    """Extract domains from analysis data"""
    domains = []
    for entry in data:
        # In a real implementation, you would extract the domain from the email headers
        # For now, we'll use dummy domains for demonstration
        domains.append("example.com")
    return domains 